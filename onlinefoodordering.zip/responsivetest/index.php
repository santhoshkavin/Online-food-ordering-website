<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        
        <title></title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link href="bootstrap/css/bootstrap-theme.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.css" type="text/css"/>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
<script src="https://maxcdn.bootstarpcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
    </head>
    <style>
    </style>
    <body>
        
        <div class="back" style="background: white">
        <!--<div class="panel panel-primary">
                <div class="panel-heading">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="navbar-header">
                         <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                        <a href="#" class="navbar-brand" style="margin-left: 50px;font-size: 20px;color: black"><b>Favorite Chicken and Ribs Bethnal Green<img src="images/icon.png" style="width: 60px;height: 55px;margin-top: -20px;"></b></a>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="signup.php" style="margin-right:30px;font-size: 16px;color: black;"><span class="glyphicon glyphicon-user"></span>Sign Up</a></li>
                            <li><a href="login.php" style="margin-right:30px;font-size: 16px;color: black;"><span class="glyphicon glyphicon-log-in"></span>Log In</a></li>
                        </ul>
                    </div>
                </nav>
                    </div>
        </div>-->
        
<div class="mobile-container">

<!-- Top Navigation Menu -->
<div class="navbar-fixed-top">
<div class="topnav">
    <a href="#" class="active"><b>Favorite Chicken and Ribs Bethnal Green<img src="images/icon.png" style="width: 60px;height: 55px;margin-top: -20px;"></b></a>
  <div id="myLinks">
      <a href="#" style="text-align: center;">SIGN UP</a>
      <a href="login.php" style="text-align: center;">LOGIN</a>
  </div>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
</div>
</div>
        <script>      
function myFunction() {
  var x = document.getElementById("myLinks");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}
</script>
            <script>
                if ("geolocation" in navigator) {
  // check if geolocation is supported/enabled on current browser
  navigator.geolocation.getCurrentPosition(
   function success(position) {
     // for when getting location is a success
     document.write('latitude', position.coords.latitude, 
                 'longitude', position.coords.longitude);
   },
  function error(error_message) {
    // for when getting location results in an error
    console.error('An error has occured while retrieving
                  location', error_message)
  }  
});
} else {
  // geolocation is not supported
  // get your location some other way
  console.log('geolocation is not enabled on this browser')
}
//favoriteimage
            </script>
            <div class="non-container">
                <img src="images/kfclimitedboxoffer.png" class="img-banner" style="margin-top:70px;"/>
        </div>
               
<h3 style="width: 100%;text-align: center;"><i style="width: 100%;text-align: center;">Favorite is waiting to deliver your favorite food</i></h3>
<div class="container">
<div class="wrapper">
    <article class="img-info">
                <h2>About Us:</h2>
                <p>Yellow Leaf Hammocks tells users about its product by
describing how the hammocks empower artisan weavers and their families.
The company breaks down different pieces of the story into sections that combine words and easily digestible 
graphics, painting a picture instead of big chunks of text. They were clear about why they were different: "Not a Charity,"
the page reads. And then: "This is the basis for a brighter future, built on a hand up, not a handout.
               
The company breaks down different pieces of the story into sections that combine words and easily digestible 
graphics, painting a picture instead of big chunks of text. They're clear about why they're different: "Not a Charity,"
the page reads. And then: "This is the basis for a brighter future, built on a hand up, not a handout. </p>
    </article>
    <img src="images/kfcimageuse1.jpg" class="mySlides1"/>
    <img src="images/kfcimageuse21.jpg" class="mySlides1" />
    <img src="images/kfcimageuse3.jpg" class="mySlides1"/>
        </div>
</div>

<div class="topictxt">
    <div class="container">
        <h3><b>BROWSE CATEGORIES-----------------------------</b></h3>
    </div>
</div>

<div class="categories">
    <article class="img1">
        <img src="images/kfcimageuse1.jpg" />
        <h4><b>Chicken</b></h4>
    </article>
    <article class="img2">
        <img src="images/kfcimageuse21.jpg" />
        <h4><b>Burgers</b></h4>
    </article>
    <article class="img3">
        <img src="images/kfcimageuse3.jpg" />
        <h4><b>Rice Bowl</b></h4>
    </article>
    <article class="img3">
        <img src="images/kfcboxmealbanner.png" />
        <h4><b>Snacks and Beverages</b></h4>
    </article>
</div>

<!--<div class="wrappertest">
 <article class="special-off" >
     <div class="thumbnail" style="padding:10px;">
         <img src="images/frontpag1.jpg" />
     </div>
              </article>
 <article class="special-off1" >
     <div class="thumbnail" style="padding:10px;">
         <img src="images/frontpag2.jpg" />
     </div>
             </article>
    
 <article class="special-off2" >
     <div class="thumbnail" style="padding:10px;">
         <img src="images/frontpag3.jpg" />
     </div>
    </article>
     
 <article class="special-off3" >
     <div class="thumbnail" style="padding:10px;">
         <img src="images/frontpag4.jpg" />
     </div>
                
    </article>
    </div>-->

<?php 
$con = mysqli_connect('localhost', 'root','','dominos_test')
        or die($mysqli_error($con));
$select_query = "select *from image";
$select_query_result = mysqli_query($con,$select_query);

while($row = mysqli_fetch_array($select_query_result)){
   // $image = $row['Imageins'];
   // if($image != ""){
echo'';
    //}
}
?>

  <script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides1");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>
   <?php
        // put your code here
        ?>
<!--
<div class="wrappertest">
 <article class="special-off" >
     <div class="thumbnail" style="padding:10px;">
         <img src="images/frontpag1.jpg" />
     </div>
                <p>Yellow Leaf Hammocks tells users about its product by
describing how the hammocks empower artisan weavers and their families.
The company breaks down different pieces of the story into sections that combine words and easily digestible 
graphics, painting a picture instead of big chunks of text. They were clear about why they were different: "Not a Charity,"
the page reads. And then: "This is the basis for a brighter future, built on a hand up, not a handout. </p>
    </article>
 <article class="special-off1" >
     <div class="thumbnail" style="padding:10px;">
         <img src="images/frontpag2.jpg" />
     </div>
                <p>Yellow Leaf Hammocks tells users about its product by
describing how the hammocks empower artisan weavers and their families.
The company breaks down different pieces of the story into sections that combine words and easily digestible 
graphics, painting a picture instead of big chunks of text. They were clear about why they're different: "Not a Charity,"
the page reads. And then: "This is the basis for a brighter future, built on a hand up, not a handout.</p>
    </article>
    
 <article class="special-off2" >
     <div class="thumbnail" style="padding:10px;">
         <img src="images/frontpag3.jpg" />
     </div>
                <p>Yellow Leaf Hammocks tells users about its product by
describing how the hammocks empower artisan weavers and their families.
The company breaks down different pieces of the story into sections that combine words and easily digestible 
graphics, painting a picture instead of big chunks of text. They're clear about why they're different: "Not a Charity,"
the page reads. And then: "This is the basis for a brighter future, built on a hand up, not a handout. </p>
    </article>
     
 <article class="special-off3" >
     <div class="thumbnail" style="padding:10px;">
         <img src="images/frontpag4.jpg" />
     </div>
                <p>Yellow Leaf Hammocks tells users about its product by
describing how the hammocks empower artisan weavers and their families.
The company breaks down different pieces of the story into sections that combine words and easily digestible 
graphics, painting a picture instead of big chunks of text. They're clear about why they're different: "Not a Charity,"
the page reads. And then: "This is the basis for a brighter future, built on a hand up, not a handout.</p>
    </article>
    </div>-->

        </div>
<div class="footer">
<div class="section">
    <div class="container">
        <h2 style="color: black; margin-top: 20px;"><b>OFFERS AND DEALS -----------------</b></h2>
         <div class="content">
                <div class="card1">
                    <img src="images/offerdeal1.png"/>
                </div>
                <div class="card2">
                    <h4>Far and away the best prize that life has to offer is the chance to work hard
                        at work worth doing. - Theodore Roosevelt. I offer you peace. I offer you love.
                        I offer you friendship. I see your beauty</h4>
                    <input type="submit" class="btn btn-danger" value="Check more">
                </div>
        </div>
        <div class="content1">
                <div class="card1">
                    <img src="images/offerdeal2.png"/>
                </div>
                <div class="card2">
                     <h4>Far and away the best prize that life has to offer is the chance to work hard
                        at work worth doing. - Theodore Roosevelt. I offer you peace. I offer you love.
                        I offer you friendship. I see your beauty</h4>
                    <input type="submit" class="btn btn-danger" value="Check more">
                </div>
        </div>
        <div class="content2">
                <div class="card1">
                    <img src="images/offerdeal3.png"/>
                </div>
                <div class="card2">
                     <h4>Far and away the best prize that life has to offer is the chance to work hard
                        at work worth doing. - Theodore Roosevelt. I offer you peace. I offer you love.
                        I offer you friendship. I see your beauty</h4>
                    <input type="submit" class="btn btn-danger" value="Check more">
                </div>
        </div>
         </div>
        </div>
</div>
        <div class="container" style="background: black;">
            <div class="leftimg">
                <img src="images/icon.png">
                <div class="right1">
            <a href=""><h4>Kfc Food</h4></a>
            <a href=""><h4>Menu</h4></a>
            <a href=""><h4>Order lookup</h4></a>   
            <a href=""><h4>Gift card</h4></a>
            </div>
                <div class="right2">
                <a href=""><h4>Support</h4></a>
            <a href=""><h4>Get help</h4></a>
            <a href=""><h4>Contact us</h4></a>   
            <a href=""><h4>Feedback</h4></a>
                </div>
        </div>
            <div class="rightimg">
                <img src="images/kfclimitedboxoffer.png" />
            </div>
        </div>
    </body>
    </div>
</html>

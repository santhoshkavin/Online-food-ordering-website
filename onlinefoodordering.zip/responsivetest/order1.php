<?php
session_start();
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*echo '<div class="icon"><img src="images/icon.png"/><img src="images/favoritevision.jpg"/></div>';
*/
$_SESSION["favcolor"] = $_POST['firstname'];
$name = $_SESSION["favcolor"];
echo $name;

$con = mysqli_connect('localhost', 'root','','dominos_test')
        or die($mysqli_error($con));
$select_query = "select *from image";
$result = mysqli_query($con,$select_query);

while($row = mysqli_fetch_array($result)){
    $url = $row['Imageurl'];
    $dishname = $row['dishname'];
    $rate = $row['Rate'];
    $discription = $row['Discription'];
    $id = $row['Id'];
     echo' 
    <div class="display">
 <article class="special-off">
     <a href="cart.php?myVar='.$id.'" onclick="post"><img src="data:image/jpeg;base64,'.base64_encode($url).'" style="border: 1px solid black;background: url(images/bgorder.jpg)"/></a>

          <p style="text-align: center;font-weight: bold;"><b>'.$dishname.'</b></p>
            <p style="text-align: center;font-weight:bold;">'.$discription.'</p>   
                
            <h4 style="text-align: center;">'.$rate.'</h4>
            <h4 style="text-align: center;"> Buy 2 and get 10% Discount</h4>
                  
     <a href="cart.php?myVar=1" onclick="post"><u><h4 style="text-align: center;">Add to Cart</h4></u></a>
        
         </article>
        </div>';
    }
    
?>
<!DOCTYPE>
<html>
    <head>
        
        <meta charset="UTF-8">
        
        <title></title>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link href="bootstrap/css/bootstrap-theme.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.css" type="text/css"/>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
<script src="https://maxcdn.bootstarpcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="order.css">
        <title>Login Page</title>
    </head>
    <body>
      <!--  <div class="panel panel-primary">
            <div class="panel-heading">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a href="#" class="navbar-brand" style="margin-left: 50px;font-size: 20px;color: black;"><b>Favorite Chicken and Ribs Bethnal Green<img src="images/icon.png" style="width: 60px;height: 55px;margin-top: -20px;"></b></a>
                    </div>
                    <div class="collapse navbar-collapse"id="myNavbar">
                            <ul class="nav navbar-nav navbar-right">
                                
                            <li><a href="signup.php" style="margin-right:15px;font-size: 16px;color: black;"><span class="glyphicon glyphicon-shopping-cart"></span>Cart</a></li>
                            <li><a href="login.php" style="margin-right:18px;font-size: 16px;color: black;"><span class="glyphicon glyphicon-log-out"></span>LogOut</a></li>
                        
                            </ul>
                    </div>
                </nav>
            </div>
        </div>-->
        
         <div class="outside">
        <img src="images/dominos1.jpg">
            </div>
        <?php 
         echo $_SESSION["favcolor"];
        ?>
    </body>
</html>


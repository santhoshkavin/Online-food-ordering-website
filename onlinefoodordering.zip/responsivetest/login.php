<?php
session_start();
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>
<script type="text/javascript" language="javascript">
    window.history.forward();
</script>
<!DOCTYPE>
<html>
    <head>
        
        <meta charset="UTF-8">
        <title></title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link href="bootstrap/css/bootstrap-theme.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.css" type="text/css"/>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
<script src="https://maxcdn.bootstarpcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="login.css">
        <title>Login Page</title>
    </head>
    <body>
      <!-- <div class="panel panel-primary">
            <div class="panel-heading">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a href="#" class="navbar-brand" style="margin-left: 50px;font-size: 20px;color: black"><b>Favorite Chicken and Ribs Bethnal Green<img src="images/icon.png" style="width: 60px;height: 55px;margin-top: -20px;"></b></a>
                    </div>
                    <div class="collapse navbar-collapse"id="myNavbar">
                            <ul class="nav navbar-nav navbar-right">
                                
                            <li><a href="signup.php" style="margin-right:30px;font-size: 16px;color: black;"><span class="glyphicon glyphicon-user"></span>Sign Up</a></li>
                            <li><a href="login.php" style="margin-right:30px;font-size: 16px;color: black;"><span class="glyphicon glyphicon-log-in"></span>Log In</a></li>
                        
                            </ul>
                    </div>
                </nav>
            </div>
        </div>-->
      
<div class="mobile-container">

<!-- Top Navigation Menu <img src="images/icon.png" style="width: 60px;height: 55px;margin-top: -20px;">-->
<div class="navbar-fixed-top">
<div class="topnav">
    <a href="#" class="active"><b>Favorite Chicken and Ribs Bethnal Green</b></a>
  <div id="myLinks">
      <a href="#" style="text-align: center;">SIGN UP</a>
      <a href="index.php" style="text-align: center;">ABOUT US</a>
  </div>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
</div>
</div>
        <script>      
function myFunction() {
  var x = document.getElementById("myLinks");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}
</script>
<div class="back">
        <div class="container">
            <div class="wrapper">
            <div class="loginpage">
                <form method="post" action="cart.php">
                <div class="form-group">
                    <label>Email.</label></br>
                    <input type="text" placeholder="Email" name="firstname" class="form-control" style="border: 3px solid black;"/>
                </div>
                <div class="form-group">
                    <label>Password</label></br>
                    <input type="password" placeholder="Password" name="password" class="form-control" style="border: 3px solid black;"/>
                </div>
                <div class="button">
                    <button type="submit" name="Submit"  onclick=""
                            class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
        </div>
        </div>
</div>
        <div class="display">    
            <div class="thumbnail">
                <p>Gallery<img src="images/icon.png" style="width:50px; height: 50px;"></p>
            </div>
        </div>  
<?php 
$con = mysqli_connect('localhost', 'root','','dominos_test')
        or die($mysqli_error($con));
$select_query = "select *from gallery";
$select_query_result = mysqli_query($con,$select_query);

while($row = mysqli_fetch_array($select_query_result)){
    $image = $row['Image'];
    if($image != ""){
echo'
<div class="wrappertest">
 <article class="special-off" >
     <div class="thumbnail" style="padding:10px;">
     <img src="data:image/jpeg;base64,'.base64_encode($image).'" />
     </div>
    </article>
</div>';
    }
}
?>
    </body>
</html>


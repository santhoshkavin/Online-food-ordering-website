<?php
session_start();
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

 if (isset($_POST['Submit'])) { 
 $_SESSION['favcolor'] = $_POST['firstname'];
 $_SESSION['pass']  = $_POST['password'];
 if ($_SESSION['favcolor'] == "santhoshsubash14@gmail.com" && $_SESSION['pass'] == "123456")  {
            header("Location: order.php");
        } 
        elseif($_SESSION['favcolor'] == "santhoshsubash10@gmail.com" && $_SESSION['pass'] == "123456"){
      header("Location: order.php");
 }
 else{
     
 }
 } 
$name = $_SESSION['favcolor'];
/*$name = $_GET['name'];
$val = $_GET['myVar'];
echo $val;

$con = mysqli_connect('localhost','root','','dominos_test')
        or die(mysqli_error($con));
$select_query = "insert into name values ('$name','$val')";
$result = mysqli_query($con, $select_query);

header("Location: order1.php");*/
?>
<html>
  <head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <script src="jquery-2.1.4.js"></script>
  <link rel="stylesheet" type="text/css" href="styles.css">
  
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link href="bootstrap/css/bootstrap-theme.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.css" type="text/css"/>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
<script src="https://maxcdn.bootstarpcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  
  <body>
  <div id="navbar"><span>Red Stapler - Geolocation API</span></div>
  <div id="wrapper">
    <button id="location-button">Get User Location</button>
    <div id="output"></div>
  </div>
  <p id="startLat"></p>
  <p id="startLon"></p>
  <script>
      window.onload = function() {
  //var startPos;
  var i;
 var geoSuccess = function(position) {
  startPos = position;
  for(i=0;i<8;i++){
 document.getElementById('startLat').innerHTML = startPos.coords.latitude;
  document.getElementById('startLon').innerHTML = startPos.coords.longitude;
  }
  };
   document.getElementById('startLat').innerHTML = navigator.geolocation.getCurrentPosition(geoSuccess);
  
   var url = "https://maps.google.com/?q=" + Lat + "," + Lng;
   window.open(url);
  enableHighAccuracy: true;
  
};
</script>
 <div id="cart"  style="clear:both"></div>  
                <br />  
                <div class="container">
                <h3>Order Details</h3>  
                <div class="table-responsive">  
                     <table class="table table-bordered">  
                          <tr>  
                              <th width="40%" style="text-align: center">Item Name</th>  
                               <th width="5%">Quantity</th>  
                               <th width="15%">Price</th>  
                               <th width="15%">Total</th>  
                               <th width="12%">Action</th>   
                               <th width="10%">Image</th>  
                          </tr>  
                          <?php   
                               
$con = mysqli_connect('localhost','root','','dominos_test')
        or die(mysqli_error($con));
$select_query = "select *from name where Name='$name'";
$result = mysqli_query($con, $select_query);

while($row = mysqli_fetch_array($result)){
    $val = $row['Id'];
    $select_query = "select *from image where Id=$val";
$result_1 = mysqli_query($con, $select_query);

while ($row = mysqli_fetch_array($result_1)){
                          ?>  
                          <tr>  
                              <td style="text-align: center;padding-top: 20px;"><b><?php echo $row['Id']; ?></b></td>  
                              <td><b><?php echo $row['dishname']; ?></b></td>  
                              <td><b>$ <?php echo $row['Rate']; ?></b></td>  
                              <td><b>$ <?php echo $row['Rate']; ?></b></td>  
                              <td><?php
    echo '<img src="data:image/jpeg;base64,'.base64_encode($row["Imageurl"]).'" style="width:50px;height:50px;" />'; ?>
    </td>
                        <!--      <td><b>$ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2); ?></b></td>  
                               <td  style="text-align: center;"><a href="order.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Remove</span></a></td>  
                          --> </tr>
                          
<?php 
}
}
                     
                          ?> <tr>
<td colspan="3" align="right"><b><?php echo $_SESSION['favcolor'];?></b></td>  
                              <td align="right"><b>$ <?php echo number_format($total, 2); ?></b></td>  
                     </tr>
                     </table>
                </div>
                </div>
                
  </body>
</html>






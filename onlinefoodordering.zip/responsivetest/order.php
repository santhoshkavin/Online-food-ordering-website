<?php

 session_start();  
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 
 if (isset($_POST['Submit'])) { 
 $_SESSION['favcolor'] = $_POST['firstname'];
 } 
 $connect = mysqli_connect("localhost", "root", "", "dominos_test"); 
 
 if(isset($_POST["add_to_cart"]))  
 {  
      if(isset($_SESSION["shopping_cart"]))  
      {  
           $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");  
           if(!in_array($_GET["id"], $item_array_id))  
           {  
                $count = count($_SESSION["shopping_cart"]);  
                $item_array = array(  
                     'item_id'               =>     $_GET["id"],  
                     'item_name'               =>     $_POST["hidden_name"],  
                     'item_price'          =>     $_POST["hidden_price"],  
                     'item_quantity'          =>     $_POST["quantity"]
                        
                );  
                $_SESSION["shopping_cart"][$count] = $item_array;  
           }  
           else  
           {  
                echo '<script>alert("Item Already Added")</script>';  
                echo '<script>window.location="order.php"</script>';  
           }  
      }  
      else  
      {  
           $item_array = array(  
                'item_id'               =>     $_GET["id"],  
                'item_name'               =>     $_POST["hidden_name"],  
                'item_price'          =>     $_POST["hidden_price"],  
                'item_quantity'          =>     $_POST["quantity"]
           );  
           $_SESSION["shopping_cart"][0] = $item_array;  
            
      }  
 }  
 if(isset($_GET["action"]))  
 {  
      if($_GET["action"] == "delete")  
      {  
           foreach($_SESSION["shopping_cart"] as $keys => $values)  
           {  
                if($values["item_id"] == $_GET["id"])  
                {  
                     unset($_SESSION["shopping_cart"][$keys]);  
                     echo '<script>alert("Item Removed")</script>';  
                     echo '<script>window.location="order.php"</script>';  
                }  
           }  
      }  
 }  
 
 if(isset($_GET["action"]))  
 {  
      if($_GET["action"] == "Removeall")  {
          
                     unset($_SESSION["shopping_cart"]);
                     echo '<script>window.location="login.php"</script>';
                     
      }
 }
 
 if(isset($_GET["action"])){
     
     if($_GET["action"] == "checkout"){
         
         $valink = $_GET['value'];
         
         $username = $_SESSION['favcolor'];  
$con = mysqli_connect('localhost','root','','dominos_test')
        or die(mysqli_error($con));
$select_query = "insert into username values ('$username')";
$result = mysqli_query($con, $select_query);
     
   if(!empty($_SESSION["shopping_cart"]))  
                          {  
                               $total = 0;  
                               foreach($_SESSION["shopping_cart"] as $keys => $values)  
                               {  
 
                               
          $name =  $_SESSION['favcolor'];
          $val = $values["item_id"];
          $dishname = $values["item_name"];
           
$con = mysqli_connect('localhost','root','','dominos_test')
        or die(mysqli_error($con));
$select_query = "insert into name(Id,Name,dishname) values ('$val','$name','$dishname')";
$result = mysqli_query($con, $select_query);
                               }
                               }
                            //   unset($_SESSION["shopping_cart"]);
                               
                     echo '<script>window.location="payTm/PaytmKit/TxnTest.php"</script>';  
     /*   </div>
        </body>
        </html>';*/
                       //  echo   ' <script>
                          //   window.location = "https://www.paypal.me/santho116/'.$valink.'";
                             // </script>';
                  //             echo '<script src="https://www.paypal.com/sdk/js?client-id=sb">
                      //         </script>
                          //     <script>paypal.Buttons().render("body");</script>;';
     }
 }
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Webslesson Tutorial | Simple PHP Mysql Shopping Cart</title>  
          <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  -->
           
        <meta charset="UTF-8">
        
        <title></title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" /><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link href="bootstrap/css/bootstrap-theme.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.css" type="text/css"/>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
<script src="https://maxcdn.bootstarpcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="order.css">
        <title>Login Page</title>
      </head>  
      <body>    
         <!--  <div class="panel panel-primary">
            <div class="panel-heading">
                <nav class="navbar navbar-default navbar-fixed-top">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a href="#" class="navbar-brand" style="margin-left: 50px;font-size: 20px;color: black;"><b>Favorite Chicken and Ribs Bethnal Green<img src="images/icon.png" style="width: 60px;height: 55px;margin-top: -20px;"></b></a>
                    </div>
                    <div class="collapse navbar-collapse"id="myNavbar">
                             
                     <form method="post" action="order.php?action=add&id=<?php echo $row["Id"]; ?>">    
                            <ul class="nav navbar-nav navbar-right"> 
                            <li><a href="#cart" style="margin-right:15px;font-size: 16px;color: black;"><span class="glyphicon glyphicon-shopping-cart"></span>Cart</a></li>
                            <li><a href="order.php?action=Removeall" style="margin-right:15px;font-size: 16px;color: black;"><span class="glyphicon glyphicon-log-out"></span>LogOut</a></li>
                            </ul>
                     </form> 
                    </div>
                </nav>
            </div>
        </div><img src="images/icon.png" style="width: 60px;height: 55px;margin-top: -20px;">-->
         
<div class="mobile-container">

<!-- Top Navigation Menu -->
<div class="navbar-fixed-top">
<div class="topnav">
    <a href="#" class="active"><b>Favorite Chicken and Ribs Bethnal Green</b></a>
  <div id="myLinks">
      <a href="#cart" style="text-align: center;"><span class="glyphicon glyphicon-shopping-cart"></span>CART</a>
    <a href="order.php?action=Removeall" style="text-align: center;"><span class="glyphicon glyphicon-log-out"></span>LOGOUT</a>
  </div>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
</div>
</div>
        <script>      
function myFunction() {
  var x = document.getElementById("myLinks");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}
</script>

         <br />   
                <?php  
                $query = "SELECT * FROM image ORDER BY id ASC";  
                $result = mysqli_query($connect, $query);  
                if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
                ?>  
         <div class="display">
                    <div class="special-off">
                        <form method="post" action="order.php?action=add&id=<?php echo $row["Id"]; ?>" target="frame" >  
                          <div style="padding:3px;" align="center">  
                              <img src="data:image/jpeg;base64,<?php echo base64_encode($row["Imageurl"]); ?>" 
                                  style="border: 1px solid black;background: url(images/bgorder.jpg)" class="img-responsive" /><br />  
                         
                              <div class="test">
                              <h4 class="text-info"><b><?php echo $row["dishname"]; ?></b></h4>   
                              <h4 class="text-info"><?php echo $row["Discription"]; ?></h4>  
                               <h4 class="text-danger">$ <?php echo $row["Rate"]; ?></h4> 
                               <input type="text" name="quantity" class="form-control" value="1" />  
                               <input type="hidden" name="hidden_name" value="<?php echo $row["dishname"]; ?>" />  
                               <input type="hidden" name="hidden_price" value="<?php echo $row["Rate"]; ?>" /> 
                              <input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />  
                              </div>
                    </div>
                     </form>  
                        
                </div>  
                <?php  
                     }
                }
                ?> 
                <div id="cart"  style="clear:both"></div>  
                <br />  
                <div class="container" style="background-color: white;">
                <h3>Order Details</h3>       
                <div class="table-responsive" >  
                     <table class="table table-bordered">  
                         <tr>
                              <th width="100%" style="text-align: center;">Place Your orders<br/>
                              Favorite is waiting to deliver your Favorite Food</th>
                         </tr>
                     </table>
                </div>
                <div class="table-responsive" >  
                     <table class="table table-bordered">  
                          <tr>  
                              <th width="40%" style="text-align: center;">Item Name</th>  
                               <th width="5%">Quantity</th>  
                               <th width="15%">Price</th>  
                               <th width="15%">Total</th>  
                               <th width="12%">Action</th>   
                               <th width="10%">Image</th>  
                          </tr>  
                     
                          <?php   
                          if(!empty($_SESSION["shopping_cart"]))  
                          {  
                               $total = 0;  
                               foreach($_SESSION["shopping_cart"] as $keys => $values)  
                               {  
                          ?>  
                          <tr>  
                              <td style="text-align: center;padding-top: 20px;"><b><?php echo $values["item_name"]; ?></b></td>  
                              <td><b><?php echo $values["item_quantity"]; ?></b></td>  
                              <td><b>$ <?php echo $values["item_price"]; ?></b></td>  
                              <td><b>$ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2); ?></b></td>  
                               <td  style="text-align: center;"><a href="order.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Remove</span></a></td>  
                          
                               <td  style="text-align: center;">  <?php

                               
                               $val = $values["item_id"];
$con = mysqli_connect('localhost','root','','dominos_test')
        or die(mysqli_error($con));
$select_query_1 = "select *from image where Id='$val'";
$result_1 = mysqli_query($con, $select_query_1);

while ($row = mysqli_fetch_array($result_1)){
    
    echo '<img src="data:image/jpeg;base64,'.base64_encode($row["Imageurl"]).'" style="width:50px;height:50px;" />';
    
}

?></td>
                          </tr>  
                          <?php  
                           //
                           //    
                           //        
                           //            
                           //                    unset($_SESSION["shopping_cart"]);
                                    $total = $total + ($values["item_quantity"] * $values["item_price"]);  
                               }  
                          ?>  
                          <tr> <!-- https://www.paypal.me/santho116/<?php echo number_format($total, 2);?>"-->
                              <td colspan="3" align="right"><b><?php echo $_SESSION['favcolor'];?></b></td>  
                              <td align="right"><b>$ <?php echo number_format($total, 2); ?></b></td>  
                              <td colspan="6" align="center">
                               <!--   <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
    <input type="hidden" name="amount" value="<?php echo number_format($total, 2);?>">
<input type="hidden" name="cmd" value="_s-xclick">
<input type="hidden" name="hosted_button_id" value="BE25QMRLE5B9A">       
<input type="image" src="https://www.paypalobjects.com/en_GB/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" value="<?php echo number_format($total, 2);?>" alt="PayPal – The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1"  height="1">
</form>
                               
    <!-- Set up a container element for the button -->
 <!--  <div id="paypal-button-container"></div>

    <!-- Include the PayPal JavaScript SDK
    <script src="https://www.paypal.com/sdk/js?client-id=AT2nMVdzU2oikLzIn1l7XrrqpVPOCrkQHXtUfGFkWTWdQ-uE6oNwoo4EUBSVz1IW-3CR93X0gHQYLq39&currency=INR"></script>
<script>
    
        
</script>
    <script>
        // Render the PayPal button into #paypal-button-container\
        var input = <?php echo number_format($total, 2);?>;
        paypal.Buttons({
            // Set up the transaction
            createOrder: function(data, actions) {
                return actions.order.create({
                    purchase_units: [{
                        amount: {
                            value: '0.01'             }
                    }]
                });
            },

            // Finalize the transaction
            onApprove: function(data, actions) {
                return actions.order.capture().then(function(details) {
                    // Show a success message to the buyer
                    alert('Transaction completed by ' + details.payer.name.given_name + '!');
                });
            }


        }).render('#paypal-button-container');
        </script></td>
<a href="order.php?action=checkout&value=<?php echo number_format($total, 2);?>"><input type="button" value="Proceed to Checkout" class="btn btn-success"></a>-->  
                          
    <a href="order.php?action=checkout"><input type="button" value="Proceed to Checkout" class="btn btn-success"></a>
                          </tr>  
                          <?php  
                          }  
                          ?>  
                     </table>  
                </div>  
                </div>
                </div>
           <br />  
           <div class="outside">
               <img src="images/kfcboxmealbanner.png">
             </div>
            </div>
           
      </body>  
 </html>
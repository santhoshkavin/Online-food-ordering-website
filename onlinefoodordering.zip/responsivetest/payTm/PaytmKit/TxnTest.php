<?php
session_start();
	header("Pragma: no-cache");
	header("Cache-Control: no-cache");
	header("Expires: 0");
        
           if(!empty($_SESSION["shopping_cart"]))  
                          {  
                               $total = 0;  
                               foreach($_SESSION["shopping_cart"] as $keys => $values)  
                               {  
                                   
                                    $total = $total + ($values["item_quantity"] * $values["item_price"]);  
                               }
                               $value = $total;
                          }
                          
                          
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Merchant Check Out Page</title>
<meta name="GENERATOR" content="Evrsoft First Page">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link href="bootstrap/css/bootstrap-theme.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.css" type="text/css"/>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
<script src="https://maxcdn.bootstarpcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >

        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!--Latest compiled and minified JavaScript --> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta charset="UTF-8">
         <link rel="stylesheet" href="Txntest.css">
</head>
<style>
    
    th{
        text-align: center;
        padding: 10px;
    }
    td{
        text-align: center;
        padding: 10px;
    }
    table{
        text-align: center;
    }
    
    
</style>
<body>
	
<div class="mobile-container">

<!-- Top Navigation Menu -->
<div class="navbar-fixed-top">
<div class="topnav">
    <a href="#" class="active"><b>Favorite Chicken and Ribs Bethnal Green</b></a>
  <div id="myLinks">
      <a href="http://localhost/responsivetest/order.php" style="text-align: center;">Purchase More</a>
    <a href="http://localhost/responsivetest/login.php" style="text-align: center;">Logout</a>
  </div>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
</div>
</div>
        <script>      
function myFunction() {
  var x = document.getElementById("myLinks");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}
</script>


    <div class="bg">
        <div class="container">
            <div class="thumbnail">
        <article class="wrapper">
            <form method="post" action="pgRedirect.php">
                <div class="table-responsive">
                    <table class="table table-bordered" border="1">
			<tbody>
				<tr>
					<th>S.No</th>
					<th>Label</th>
					<th>Value</th>
				</tr>
                               <tr> 
                                    <td>1</td>
                                    <td><label>ORDER: </label></td>
                                    <td> <input id="ORDER_ID" tabindex="1" maxlength="20" size="20" onkeydown="return false" 
                                                 name="ORDER_ID" autocomplete="off" style="border: none;"
                                                 value="<?php echo  "ORDS" . rand(10000,99999999)?>"> </td>
                                 </tr> 
                                   <tr>
                                    <td>2</td>
                                    <td><label>CUST_ID: </label></td> 
                                    <td><input id="CUST_ID" tabindex="2" maxlength="20" onkeydown="return false" size="20" name="CUST_ID" autocomplete="off" 
                                               style="border: none;"
                                                   value="<?php echo  "CUST" . rand(10000,99999999)?>"></td>
                                       </tr>
                                        <tr>
                                    <td>3</td>
                                    <td><label>INDUSTRY_TYPE_ID: </label></td>
                                    <td><input id="INDUSTRY_TYPE_ID" tabindex="4" onkeydown="return false" maxlength="20" style="border: none;" size="20" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail">
                                        </td>
                                     </tr>
                                        <tr>
                                    <td>4</td>
                                    <td><label>CHANNEL_ID: </label></td>
                                    <td><input id="CHANNEL_ID" tabindex="4" maxlength="20" onkeydown="return false" style="border: none;" 
                                                   size="20" name="CHANNEL_ID" autocomplete="off" value="WEB"> </td>
                                      </tr> 
                                      <tr>
                                    <td>5</td>
                                    <td><label>TXN_AMOUNT: </label></td>
					<td><input title="TXN_AMOUNT" tabindex="10" maxlength="20"
                                                   size="20" style="border: none;"
                                               type="text" name="TXN_AMOUNT" onkeydown="return false"
                                               value="<?php echo $value?>"</td>
                                       </tr>
                                        <tr>
                                            <td></td>
					<td></td>

                                        <td><input value="Pay Now" type="submit" class="btn btn-success" ></td>
                                        </tr>
                                      
            </tbody>
		</table>
                </div>
                                      
        </form>
            <img src="icon.png">
                        <div class="container">
            <div class="arrange">
                <h3>Order Details</h3>  
                <div class="table-responsive">  
                     <table class="table table-bordered">  
                          <tr>  
                              <th width="30%" style="text-align: center">Item Name</th>  
                               <th width="5%">Quantity</th>  
                               <th width="15%">Price</th>  
                               <th width="15%">Total</th>  
                             <th width="10%">Image</th>  
                          </tr>  
                          <?php   
                          if(!empty($_SESSION["shopping_cart"]))  
                          {  
                               $total = 0;  
                               foreach($_SESSION["shopping_cart"] as $keys => $values)  
                               {  
                          ?>  
                          <tr>  
                              <td style="text-align: center;padding-top: 20px;"><b><?php echo $values["item_name"]; ?></b></td>  
                              <td><b><?php echo $values["item_quantity"]; ?></b></td>  
                              <td><b>$ <?php echo $values["item_price"]; ?></b></td>  
                              <td><b>$ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2); ?></b></td>  
                               <td  style="text-align: center;">  <?php

                               
                               $val = $values["item_id"];
$con = mysqli_connect('localhost','root','','dominos_test')
        or die(mysqli_error($con));
$select_query_1 = "select *from image where Id='$val'";
$result_1 = mysqli_query($con, $select_query_1);

while ($row = mysqli_fetch_array($result_1)){
    
    echo '<img src="data:image/jpeg;base64,'.base64_encode($row["Imageurl"]).'" style="width:50px;height:50px;" />';
    
}

?></td>
                          </tr>  
                          <?php  
                                    $total = $total + ($values["item_quantity"] * $values["item_price"]);  
                               }  
                          ?>  
                          <tr> <!-- https://www.paypal.me/santho116/<?php echo number_format($total, 2);?>"-->
                              <td colspan="3" align="right"><b><?php echo $_SESSION['favcolor'];?></b></td>  
                              <td align="right"><b>$ <?php echo number_format($total, 2); ?></b></td>  
                          </tr>
                              <?php
                              
                          }
                               
                          ?>
                              </div>
        </div>
    </div>
        </article>
        </div>
    </div>
</body>
</html>